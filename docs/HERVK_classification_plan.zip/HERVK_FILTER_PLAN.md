# HERV-K Insertion Polymorphism Filter — Implementation Plan

**Project**: Probabilistic post-annotation filter for HERV-K SV polymorphism in pangenome data
**Pipeline context**: GraffiTE v1.1dev → annotated VCF → this filter
**Status at handoff**: math + reference module drafted (`hervk_classify_v2.py`), Wildschutte/HPRC inputs to be supplied by user
**Author of handoff**: Clem (with planning support from Claude on claude.ai)

---

## 1. Goal

Classify each TE-annotated structural variant in a pangenome VCF as one of four states based on its size and HERV-K family content:

| Label | Allelic transition | Canonical \|SVLEN\| |
|---|---|---|
| `H_C` | null ↔ solo-LTR | 968 bp |
| `H_B` | solo-LTR ↔ proviral | 8504 bp |
| `H_A` | null ↔ proviral | 9472 bp |
| `H_X` | non-transposition / fragment-containing SV | — |

Output a posterior probability for each hypothesis per SV, a MAP class, and a downstream interpretation of the per-haplotype 0/1 calls in terms of allelic states (null / solo / proviral).

A single SV record encodes a *bi-allelic* site. The 3-allele case (null/solo/proviral all segregating at one locus) appears as two overlapping SVs at the same locus and is handled as a post-processing merge — see §8.

## 2. Reference architecture

```
LTR5_Hs           = 968 bp     (HML-2 LTR)
HERVK-int         = 7536 bp    (HML-2 internal sequence)
solo-LTR          = 1 × LTR
proviral element  = LTR–INT–LTR  =  2 × LTR + INT  =  9472 bp
```

The four hypotheses correspond to deletion/insertion of:
- H_C: a single LTR (loss after solo-LTR-vs-null polymorphism, or insertion of a solo)
- H_B: an internal segment flanked by one LTR (LTR–INT, the *difference* between solo and proviral, since LTR–LTR recombination converts a proviral to a solo by removing 1 LTR + 1 INT = 8504 bp)
- H_A: a complete proviral element (rare in humans)

## 3. Mathematical model

For each SV `i`, observe `(s, λ, ν)`:

- `s` = `|SVLEN|`
- `λ` = bp matching any LTR-family entry (`LTR5_Hs`, `LTR5A`, `LTR5B`, `LTR5`)
- `ν` = bp matching any HERV-K internal entry (`HERVK-int`, `HERVK9-int`, `HERVK11-int`, `HERVK14-int`, `HERVK22-int`)

Per-hypothesis log-likelihood (up to additive constant):

```
log P(s, λ, ν | H_k) = -½ [ ((s − s*_k) / σ_{s,k})²
                          + ((λ − λ*_k) / σ_λ)²
                          + ((ν − ν*_k) / σ_ν)²
                          + ((s − (λ+ν)) / σ_t)² ]
```

Expected values per hypothesis (`s*, λ*, ν*`):

| | s* | λ* | ν* |
|---|---|---|---|
| H_C | 968 | 968 | 0 |
| H_B | 8504 | 968 | 7536 |
| H_A | 9472 | 1936 | 7536 |

Background hypothesis `H_X` is a flat density: `log P(s, λ, ν | H_X) = -log(S · Λ · N)` with `S=30000, Λ=5000, N=30000`.

Posterior by Bayes:

```
P(H_k | x) = π_k · P(x | H_k) / Σ_j π_j · P(x | H_j)
```

Default priors `(π_C, π_B, π_A, π_X) = (0.70, 0.10, 0.05, 0.15)` reflect that solo-LTRs dominate human polymorphism.

## 4. Inputs Claude Code will receive

```
inputs/
├── HPRCv2_GraffiTE_annotated.tsv     # GraffiTE per-SV TSV, full HPRCv2
└── wildschutte_grch38.tsv            # liftover'd Wildschutte 2016 anchors
                                      # cols: chrom, pos, type ∈ {solo, proviral, null_proviral, truncated}
```

Expected GraffiTE TSV columns (already in current pipeline output):
`CHROM, POS, END, ID, SVTYPE, SVLEN, n_hits, match_lengths, repeat_ids, matching_classes, fragmts, total_match_length, total_match_span, total_repeat_span` plus per-haplotype 0/1 columns named `<sample>_hap1` / `<sample>_hap2`.

A toy version is at `/mnt/user-data/uploads/HERVK_annot_test.tsv` (23 SVs, used during model design — keep available for regression testing).

## 5. Reference module already provided

`hervk_classify_v2.py` (in this directory) contains:

| Function | Purpose |
|---|---|
| `parse_hits(match_lengths, repeat_ids)` | Returns `(λ, ν)` from comma-separated GraffiTE annotation, handling `(x)` merge suffix |
| `log_likelihood(s, λ, ν, hyp, sigmas)` | The likelihood formula above |
| `classify_row(s, λ, ν, priors, sigmas)` | Returns posterior dict for one SV |
| `classify_table(df, priors, sigmas)` | Vectorised — adds `lambda_LTR, nu_INT, P_H_*, MAP_class` to the DataFrame |
| `fit_sigmas_empirical(labeled_df)` | MLE-style σ estimates from a labeled subset |
| `leave_one_out_accuracy(labeled_df)` | LOO validation on a labeled subset |

Module-level constants `EXPECTED, LTR_FAMILY, INT_FAMILY, DEFAULT_SIGMAS, DEFAULT_PRIORS, SIGMA_FLOORS` are exposed for tweaking.

## 6. Tasks for Claude Code

### Task A — pre-filter to single-TE-hit HERV-K SVs
Filter the GraffiTE TSV to rows where:
- `n_hits == 1` (RepeatMasker `processRepeat` already merged proviral LTR+INT into one entry tagged `(x)`)
- `matching_classes` contains `LTR/ERVK`
- After `parse_hits`, `(λ + ν) > 0` (i.e. at least some HERV-K family bp)

Save as `intermediate/hervk_candidates.tsv`. Report counts: total SVs in, kept, dropped.

### Task B — baseline classification with default σ's
Run `classify_table()` with `DEFAULT_SIGMAS` and `DEFAULT_PRIORS` over the candidates. Save `intermediate/hervk_classified_default.tsv`. Produce a small summary:

- count of SVs per MAP class
- distribution of `|SVLEN|` per MAP class (median, IQR)
- count of `(x)`-merged annotations and how they split across classes

### Task C — build Wildschutte-anchored labeled set
For each row in `wildschutte_grch38.tsv`, find HPRC SVs within ±1 kb of the lifted position on the same chromosome.

- If `≥1` candidate, pick the one whose `|SVLEN|` is closest to the canonical `s*` for the Wildschutte type (`s*_C = 968` for solo, `s*_B = 8504` for proviral, `s*_A = 9472` for null↔proviral).
- If `0` candidates: record as "Wildschutte locus not segregating in HPRC" — keep for the report, don't use for training.
- Truncated proviral: **exclude from the training set for now** (see §8 decision point).

Save `intermediate/wildschutte_labeled.tsv` with columns: original GraffiTE columns + `truth_label ∈ {A, B, C}` + `wildschutte_pos` + `dist_bp`.

Pre-fit sanity check: classify the labeled set with **default σ's** and report any disagreements between MAP class and `truth_label`. Flag those rows for human review before proceeding to Task D — disagreements at this stage usually mean the window-match grabbed the wrong nearby SV.

### Task D — fit empirical σ's and validate
After Task C disagreements are resolved (or accepted as-is), run:

```python
sigmas = fit_sigmas_empirical(labeled_df)
acc, confusion = leave_one_out_accuracy(labeled_df)
```

Acceptance criteria:
- LOO accuracy ≥ 0.90 across labeled set
- All non-zero off-diagonal entries in `confusion` reviewed and either accepted or labels corrected
- No fitted σ at the floor for a class with ≥10 labeled examples (if floored, raise the floor or revisit labels)

Save fitted sigmas to `intermediate/sigmas_fitted.json`. Report default vs fitted side-by-side.

### Task E — final classification + per-haplotype interpretation
Re-run `classify_table()` on the full candidate set with `sigmas_fitted`. For each SV with MAP class `H_C`, `H_B`, or `H_A` and posterior ≥ 0.90, propagate the genotype interpretation across haplotypes:

| MAP class | 0 means | 1 means |
|---|---|---|
| H_C | null allele | solo-LTR allele |
| H_B | solo-LTR allele | proviral allele |
| H_A | null allele | proviral allele |
| H_X | undefined — flag for exclusion | undefined |

Caveat for `INS` vs `DEL` SVTYPE: for an `INS` the alt allele is the longer one (1 = inserted state); for a `DEL` the alt allele is the shorter one (1 = deleted state). The interpretation table assumes 1 = alt = the encoded allelic state in the table. Verify this against the SVTYPE column when computing the final per-haplotype state.

Output `outputs/hervk_polymorphism_table.tsv` with:
- All candidate SVs
- `lambda_LTR, nu_INT, P_H_C, P_H_B, P_H_A, P_H_X, MAP_class, MAP_posterior`
- Per-haplotype state columns: instead of `0/1`, write `null/solo/prov` for confidently-classified sites; write `?` for `H_X` or low-posterior calls.

Output `outputs/hervk_polymorphism_summary.md` with:
- LOO confusion table on the Wildschutte anchors
- Default vs fitted σ comparison
- Per-class counts in the final classification
- Per-haplotype allele frequency for solo-LTR and proviral states (across the HPRC sample)
- List of any Wildschutte loci with no HPRC match (likely fixed or absent in HPRC)

### Task F — produce a filtered VCF
Optional but useful: if the original VCF is supplied alongside the GraffiTE TSV, emit a VCF with:
- An `INFO/HERVK_CLASS` field (one of `null_solo, solo_prov, null_prov, other`)
- An `INFO/HERVK_PMAP` field (the MAP posterior)
- Per-sample format field with the interpreted allele (e.g. `solo|null`)
- `FILTER=PASS` for confidently classified HERV-K polymorphisms; `FILTER=HERVK_AMBIG` for low-posterior or `H_X` calls that nonetheless overlap a likely HERV-K element

## 7. Validation / regression tests

The toy file `HERVK_annot_test.tsv` (23 SVs) gives expected default-σ outputs:
- 17 SVs → `H_C` (P ≈ 1.0)
- 3 SVs (8504, 8223, 8212 bp) → `H_B` (P ≈ 1.0)
- 1 SV (5405 bp, `HERVK-int(x)`) → `H_B` with P ≈ 0.999 *(borderline — may flip to `H_X` under fitted σ's)*
- 1 SV (3985 bp) → `H_X` (P = 0.996)
- 1 SV (318 bp) → `H_X` (P ≈ 1.0)

If running the v2 module on this file produces different MAP labels with default σ's, something has regressed.

## 8. Decision points / open questions

These are flagged for the user, not for autonomous resolution:

1. **Truncated proviral (5′-deleted) elements**. Wildschutte reports a few. Three options: (a) exclude from training and let them fall to `H_X`; (b) pool with `H_B` and accept wider σ_s,B; (c) introduce a fourth structured hypothesis `H_B′` with `s* ≈ 5000`, `λ* = 968`, `ν* ≈ 4000`. Default plan is (a). Flag any borderline `H_B`/`H_X` cases in the final report so the user can decide whether to upgrade to (b) or (c).

2. **Polyallelic sites**. If two HERV-K-classified SVs sit within ~100 bp of each other and one is `H_C` while the other is `H_B`, the locus may carry all three alleles (null/solo/proviral). Detect these as a post-processing step on the final table; report them but don't try to merge automatically — the per-haplotype calls need careful interpretation.

3. **Wildschutte coordinate ambiguity**. Their reported positions are sometimes the integration site, sometimes the LTR center, sometimes the deletion endpoint. ±1 kg window should swallow this, but if a Wildschutte site has multiple HPRC candidates within window, flag it for manual review rather than auto-picking by SVLEN.

4. **HPRC reference-based vs assembly-based ambiguity**. An SV called only on one haplotype graph branch may not appear in the merged VCF; be prepared for ~10% of Wildschutte sites to have no match at all.

5. **`(x)` merge inflation**. The fitted σ_λ may end up larger than expected (~400 bp) because RepeatMasker's `(x)` merging produces λ=0, ν≈8504 instead of the canonical λ=968, ν=7536 for proviral. This is correct behavior — just note it in the summary so future tuning isn't surprised.

## 9. Repository layout suggestion

```
hervk_filter/
├── README.md                          # this file
├── hervk_classify_v2.py               # core module
├── inputs/
│   ├── HPRCv2_GraffiTE_annotated.tsv
│   └── wildschutte_grch38.tsv
├── intermediate/
│   ├── hervk_candidates.tsv
│   ├── hervk_classified_default.tsv
│   ├── wildschutte_labeled.tsv
│   └── sigmas_fitted.json
├── outputs/
│   ├── hervk_polymorphism_table.tsv
│   ├── hervk_polymorphism_summary.md
│   └── hervk_polymorphism.vcf.gz       # if Task F is run
└── tests/
    └── HERVK_annot_test.tsv             # regression test fixture
```

## 10. Dependencies

```
python >= 3.10
pandas >= 2.0
numpy >= 1.24
pyliftover                # only if liftover is needed in-pipeline; user may
                          # have done this externally
pysam                     # only for Task F (VCF I/O)
```

No R dependency for the core; an R port of the classifier exists at `hervk_classify.R` for downstream use in the user's existing R workflow.

---

## Quick-start for Claude Code

```bash
cd hervk_filter/
# 1. confirm regression test passes
python3 hervk_classify_v2.py tests/HERVK_annot_test.tsv

# 2. run the pipeline (Tasks A–E) — implement as a single script
#    e.g. run_filter.py that imports from hervk_classify_v2
python3 run_filter.py \
    --graffite inputs/HPRCv2_GraffiTE_annotated.tsv \
    --wildschutte inputs/wildschutte_grch38.tsv \
    --outdir outputs/
```

The first concrete deliverable from Claude Code should be `run_filter.py` + the populated `outputs/` directory + the summary markdown. Stop after Task E and surface the summary to the user before doing Task F.
