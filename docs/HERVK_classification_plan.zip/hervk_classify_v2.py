"""
HERV-K SV polymorphism classifier — v2

Adds:
  - LTR/INT family whitelists (LTR5_Hs, LTR5A, LTR5B; HERVK-int and close
    relatives) so divergent HML-2 calls aren't dropped to H_X by mistake
  - fit_sigmas_empirical(): MLE-style sigma estimates from a labeled set
  - leave_one_out_accuracy(): sanity-check tuning quality on small samples

Run as a script to classify a TSV with the default (Wildschutte-derived or
hand-set) sigmas; import the functions to fit your own.
"""

import numpy as np
import pandas as pd

# ---- Reference architecture ------------------------------------------------
LTR_LEN, INT_LEN = 968, 7536
SOLO_PROV  = LTR_LEN + INT_LEN          # 8504
NULL_PROV  = 2 * LTR_LEN + INT_LEN      # 9472

EXPECTED = {
    'C': {'s': LTR_LEN,    'lam': LTR_LEN,   'nu': 0       },
    'B': {'s': SOLO_PROV,  'lam': LTR_LEN,   'nu': INT_LEN },
    'A': {'s': NULL_PROV,  'lam': 2*LTR_LEN, 'nu': INT_LEN },
}

# ---- Family whitelists -----------------------------------------------------
# Pool divergent HML-2 LTR labels into the LTR bucket; pool HERV-K internal
# labels into the INT bucket. Names matched after stripping '(x)'.
LTR_FAMILY = {'LTR5_Hs', 'LTR5A', 'LTR5B', 'LTR5'}
INT_FAMILY = {'HERVK-int', 'HERVK9-int', 'HERVK11-int',
              'HERVK14-int', 'HERVK22-int'}

# ---- Defaults --------------------------------------------------------------
DEFAULT_SIGMAS = {'s_C': 30.0, 's_B': 800.0, 's_A': 800.0,
                  'lam': 200.0, 'nu': 1000.0, 't': 200.0}
DEFAULT_PRIORS = {'C': 0.70, 'B': 0.10, 'A': 0.05, 'X': 0.15}

LOG_BACKGROUND = -np.log(30000.0 * 5000.0 * 30000.0)

# Numerical floor for empirically-fit sigmas — never let them collapse so
# tightly that a single outlier dominates.
SIGMA_FLOORS = {'s_C': 20, 's_B': 200, 's_A': 200,
                'lam': 50, 'nu': 200, 't': 100}


# ---- Annotation parsing ----------------------------------------------------
def parse_hits(match_lengths, repeat_ids):
    """Return (lambda, nu) — bp matching LTR family, bp matching INT family."""
    if pd.isna(match_lengths) or pd.isna(repeat_ids):
        return 0.0, 0.0
    lens = [float(x) for x in str(match_lengths).split(',')]
    ids  = [r.strip().replace('(x)', '') for r in str(repeat_ids).split(',')]
    lam = sum(L for L, r in zip(lens, ids) if r in LTR_FAMILY)
    nu  = sum(L for L, r in zip(lens, ids) if r in INT_FAMILY)
    return lam, nu


# ---- Likelihood + posterior ------------------------------------------------
def log_likelihood(s, lam, nu, hyp, sigmas):
    e, sig_s, t = EXPECTED[hyp], sigmas[f's_{hyp}'], lam + nu
    return (
        -0.5 * ((s   - e['s'])   / sig_s        ) ** 2
        -0.5 * ((lam - e['lam']) / sigmas['lam']) ** 2
        -0.5 * ((nu  - e['nu'])  / sigmas['nu'] ) ** 2
        -0.5 * ((s   - t)        / sigmas['t']  ) ** 2
    )


def classify_row(s, lam, nu, priors=DEFAULT_PRIORS, sigmas=DEFAULT_SIGMAS):
    lp = {k: log_likelihood(s, lam, nu, k, sigmas) + np.log(priors[k])
          for k in 'ABC'}
    lp['X'] = LOG_BACKGROUND + np.log(priors['X'])
    m = max(lp.values())
    e = {k: np.exp(v - m) for k, v in lp.items()}
    Z = sum(e.values())
    return {k: v / Z for k, v in e.items()}


def classify_table(df, priors=DEFAULT_PRIORS, sigmas=DEFAULT_SIGMAS):
    out = df.copy()
    rows = []
    for _, row in df.iterrows():
        lam, nu = parse_hits(row['match_lengths'], row['repeat_ids'])
        s = abs(row['SVLEN'])
        post = classify_row(s, lam, nu, priors, sigmas)
        rows.append((lam, nu, post['A'], post['B'], post['C'], post['X']))
    cols = ['lambda_LTR','nu_INT','P_H_A','P_H_B','P_H_C','P_H_X']
    out[cols] = pd.DataFrame(rows, index=df.index)
    out['MAP_class'] = out[['P_H_A','P_H_B','P_H_C','P_H_X']]\
        .idxmax(axis=1).str.replace('P_H_', '')
    return out


# ---- Empirical sigma fitting ----------------------------------------------
def fit_sigmas_empirical(labeled_df, label_col='truth_label',
                         pool_lam_nu_t=True):
    """Estimate sigmas from a labeled DataFrame.

    labeled_df must have 'SVLEN', 'match_lengths', 'repeat_ids', and a label
    column with values in {'A','B','C'} (no 'X' — those are unlabeled noise).

    Returns a dict in the same shape as DEFAULT_SIGMAS.

    Notes
    -----
    * sigma_s is fit per class (the ranges differ a lot between H_C ~968 and
      H_B ~8504).
    * sigma_lam, sigma_nu, sigma_t are pooled across classes by default —
      with ~40 sites we can't reliably estimate 12 separate parameters.
      Set pool_lam_nu_t=False if you have substantially more data.
    * Each estimate is floored by SIGMA_FLOORS to prevent overconfidence.
    """
    sigmas = dict(DEFAULT_SIGMAS)  # start from defaults; overwrite what we fit

    # parse hits once
    lam_nu = labeled_df.apply(
        lambda r: parse_hits(r['match_lengths'], r['repeat_ids']),
        axis=1, result_type='expand')
    lam_nu.columns = ['lam', 'nu']
    df = pd.concat([labeled_df.reset_index(drop=True),
                    lam_nu.reset_index(drop=True)], axis=1)
    df['s'] = df['SVLEN'].abs()

    # per-class sigma_s
    for k in ('A', 'B', 'C'):
        sub = df[df[label_col] == k]
        if len(sub) >= 3:
            resid = sub['s'] - EXPECTED[k]['s']
            est = float(np.sqrt(np.mean(resid ** 2)))
            sigmas[f's_{k}'] = max(est, SIGMA_FLOORS[f's_{k}'])

    # pooled (or per-class) sigma_lam, sigma_nu, sigma_t
    def _pooled(name, expected_fn):
        resid_sq = []
        for k in ('A', 'B', 'C'):
            sub = df[df[label_col] == k]
            if len(sub):
                e = EXPECTED[k][expected_fn] if expected_fn != 't' \
                    else (sub['lam'] + sub['nu'])
                col = sub[name] if name != 't' else sub['s']
                resid_sq.extend(((col - e) ** 2).tolist())
        return float(np.sqrt(np.mean(resid_sq))) if resid_sq else None

    if pool_lam_nu_t:
        v = _pooled('lam', 'lam')
        if v is not None: sigmas['lam'] = max(v, SIGMA_FLOORS['lam'])
        v = _pooled('nu', 'nu')
        if v is not None: sigmas['nu']  = max(v, SIGMA_FLOORS['nu'])
        v = _pooled('s', 't')
        if v is not None: sigmas['t']   = max(v, SIGMA_FLOORS['t'])
    return sigmas


def leave_one_out_accuracy(labeled_df, label_col='truth_label',
                           priors=DEFAULT_PRIORS):
    """Hold out each labeled site, refit sigmas, predict, compare. Returns
    overall accuracy and a per-class confusion dict."""
    n = len(labeled_df)
    correct = 0
    confusion = {(t, p): 0 for t in 'ABC' for p in 'ABCX'}
    for i in range(n):
        train = labeled_df.drop(labeled_df.index[i])
        test  = labeled_df.iloc[i]
        sig = fit_sigmas_empirical(train, label_col)
        lam, nu = parse_hits(test['match_lengths'], test['repeat_ids'])
        post = classify_row(abs(test['SVLEN']), lam, nu, priors, sig)
        pred = max(post, key=post.get)
        truth = test[label_col]
        confusion[(truth, pred)] += 1
        correct += (pred == truth)
    return correct / n, confusion


if __name__ == '__main__':
    import sys
    src = sys.argv[1] if len(sys.argv) > 1 \
          else '/mnt/user-data/uploads/HERVK_annot_test.tsv'
    df = pd.read_csv(src, sep='\t')
    out = classify_table(df)
    keep = ['CHROM','POS','SVTYPE','SVLEN','repeat_ids',
            'lambda_LTR','nu_INT',
            'P_H_C','P_H_B','P_H_A','P_H_X','MAP_class']
    pd.set_option('display.width', 200)
    print(out[keep].to_string(index=False, float_format=lambda x: f'{x:.3f}'))
