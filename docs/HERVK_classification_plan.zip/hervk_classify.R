# HERV-K SV polymorphism classifier (R version)
# Input: data frame from GraffiTE per-SV TSV
# Output: same data frame + lambda_LTR, nu_INT, P_H_*, MAP_class

# ---- Reference architecture ------------------------------------------------
LTR_LEN   <- 968
INT_LEN   <- 7536
SOLO_PROV <- LTR_LEN + INT_LEN          # 8504
NULL_PROV <- 2 * LTR_LEN + INT_LEN      # 9472

# Expected (s*, lam*, nu*) per hypothesis ------------------------------------
expected <- list(
  C = list(s = LTR_LEN,   lam = LTR_LEN,   nu = 0      ),  # null<->solo
  B = list(s = SOLO_PROV, lam = LTR_LEN,   nu = INT_LEN),  # solo<->proviral
  A = list(s = NULL_PROV, lam = 2*LTR_LEN, nu = INT_LEN)   # null<->proviral
)

# Default sigmas (bp) and priors --------------------------------------------
default_sigmas <- list(
  s_C  = 30,    # solo-LTRs are length-uniform
  s_B  = 800,   # allow ~10% INT truncation
  s_A  = 800,
  lam  = 200,   # tight LTR annotation
  nu   = 1000,  # absorbs INT truncation + LTR<->INT merging
  t    = 200    # SV must be mostly HERV-K
)

default_priors <- c(C = 0.70, B = 0.10, A = 0.05, X = 0.15)

# H_X flat background log-density --------------------------------------------
LOG_BACKGROUND <- -log(30000 * 5000 * 30000)

# Parse a single (match_lengths, repeat_ids) row -> c(lambda, nu) -----------
parse_hits <- function(match_lengths, repeat_ids) {
  if (is.na(match_lengths) || is.na(repeat_ids)) return(c(0, 0))
  lens <- as.numeric(strsplit(as.character(match_lengths), ",")[[1]])
  ids  <- trimws(strsplit(as.character(repeat_ids),     ",")[[1]])
  ids  <- gsub("\\(x\\)", "", ids)
  lam  <- sum(lens[ids == "LTR5_Hs"],   na.rm = TRUE)
  nu   <- sum(lens[ids == "HERVK-int"], na.rm = TRUE)
  c(lam, nu)
}

# Log-likelihood for one (s, lam, nu) under one structured hypothesis -------
log_lik <- function(s, lam, nu, hyp, sigmas) {
  e     <- expected[[hyp]]
  sig_s <- sigmas[[paste0("s_", hyp)]]
  t     <- lam + nu
  -0.5 * ((s   - e$s)   / sig_s       )^2 +
  -0.5 * ((lam - e$lam) / sigmas$lam  )^2 +
  -0.5 * ((nu  - e$nu)  / sigmas$nu   )^2 +
  -0.5 * ((s   - t)     / sigmas$t    )^2
}

# Posterior over {A, B, C, X} for one SV ------------------------------------
classify_row <- function(s, lam, nu,
                         priors = default_priors,
                         sigmas = default_sigmas) {
  lp <- c(
    A = log_lik(s, lam, nu, "A", sigmas) + log(priors["A"]),
    B = log_lik(s, lam, nu, "B", sigmas) + log(priors["B"]),
    C = log_lik(s, lam, nu, "C", sigmas) + log(priors["C"]),
    X = LOG_BACKGROUND                   + log(priors["X"])
  )
  # numerically stable softmax
  lp <- lp - max(lp)
  p  <- exp(lp); p / sum(p)
}

# Vectorised wrapper for a whole data frame ----------------------------------
classify_table <- function(df,
                           priors = default_priors,
                           sigmas = default_sigmas) {
  n   <- nrow(df)
  res <- matrix(NA_real_, nrow = n, ncol = 6,
                dimnames = list(NULL, c("lambda_LTR","nu_INT",
                                        "P_H_A","P_H_B","P_H_C","P_H_X")))
  for (i in seq_len(n)) {
    hits <- parse_hits(df$match_lengths[i], df$repeat_ids[i])
    s    <- abs(df$SVLEN[i])
    post <- classify_row(s, hits[1], hits[2], priors, sigmas)
    res[i, ] <- c(hits[1], hits[2], post["A"], post["B"], post["C"], post["X"])
  }
  out <- cbind(df, as.data.frame(res))
  out$MAP_class <- c("A null_prov","B solo_prov","C null_solo","X other")[
    apply(out[, c("P_H_A","P_H_B","P_H_C","P_H_X")], 1, which.max)
  ]
  out
}

# ---- Example use -----------------------------------------------------------
# df  <- read.delim("HERVK_annot_test.tsv", stringsAsFactors = FALSE)
# out <- classify_table(df)
# write.table(out, "HERVK_classified.tsv", sep = "\t",
#             quote = FALSE, row.names = FALSE)
