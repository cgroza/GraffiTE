#!/usr/bin/env bash
# Check the quick test's output against what GraffiTE 1.1 writes for this data set.
#   bash check.sh [output folder, default: out]
set -uo pipefail
OUT="${1:-out}"
fail=0
ok()  { echo "  [ok]   $1"; }
bad() { echo "  [FAIL] $1"; fail=1; }
records() { if [[ "$1" == *.gz ]]; then zcat "$1"; else cat "$1"; fi | grep -vc '^#'; }

expect_records() {  # expect_records <file> <count> <label>
  if [[ ! -s "$OUT/$1" ]]; then bad "$3: $OUT/$1 is missing"; return; fi
  local n; n=$(records "$OUT/$1")
  [[ "$n" -eq "$2" ]] && ok "$3: $n records" || bad "$3: $n records, expected $2"
}

expect_records 3_TSD_search/pangenome.vcf 29 "candidate TE polymorphisms (pangenome.vcf)"
expect_records 3_TSD_search/pangenome.trusted.vcf 24 "trusted subset (pangenome.trusted.vcf)"

# Which back end ran: the command line in .nextflow.log wins over quick_test.yaml,
# and GraffiTE's default is PanGenie. PanGenie cannot genotype the 14 insertions
# that contain N bases; giraffe genotypes all 29.
method=$(grep -m1 -o -- '--graph_method[ =][a-z]*' .nextflow.log 2>/dev/null | sed 's/.*[ =]//')
[[ -n "$method" ]] || method=$(sed -n 's/^graph_method: *\([a-z]*\).*/\1/p' quick_test.yaml 2>/dev/null)
[[ -n "$method" ]] || method=pangenie
if [[ "$method" == pangenie ]]; then want=15; else want=29; fi
expect_records 4_Genotyping/GraffiTE.merged.genotypes.vcf.gz "$want" "genotyped records with $method"
if [[ -s "$OUT/4_Genotyping/GraffiTE.merged.genotypes.vcf.gz" ]]; then
  samples=$(zcat "$OUT/4_Genotyping/GraffiTE.merged.genotypes.vcf.gz" | grep -m1 '^#CHROM' | cut -f10- | tr '\t' ' ')
  [[ "$samples" == "S1 S2" ]] && ok "samples: $samples" || bad "samples: '$samples', expected 'S1 S2'"
fi

if [[ $fail -eq 0 ]]; then echo "GraffiTE quick test: PASS"; else echo "GraffiTE quick test: FAIL"; fi
exit $fail
